from lpulive import User

a = User(registration_no="11917210", password="Yeahhia1236#")
# print(a.get_messages(1992013))
# print(a.get_chat_members(1992013))
# print(a.get_messages(chat_id=199201, msg_thread=False))
print(a.get_message_threads(1991112, "36nje1uvhl.1ewef614sdfsdf925747748"))
